#ifndef __LEDs
#define __LEDs

	extern int read_LEDs_ASM();
	extern void write_LEDs_ASM(int george);

#endif